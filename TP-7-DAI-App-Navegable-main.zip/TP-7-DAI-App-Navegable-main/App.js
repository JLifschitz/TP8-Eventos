import AppNavigator from './Navigator';

const App = () => {
  return (
      <AppNavigator/>
  );
};

export default App;